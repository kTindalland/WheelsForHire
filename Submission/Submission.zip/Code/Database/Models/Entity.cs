﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Database.Models
{
    public class Entity
    {
        public int Id { get; set; }
    }
}
